package com.example.zman;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnLogin, btnSignIn;
    EditText etEmail, etPassword;
    String msg = "";
    UserOpenHelper uh1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        uh1 = new UserOpenHelper(this);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(this); // is check implemented

        btnLogin = findViewById(R.id.btnLogin);
        btnSignIn = findViewById(R.id.btnSignIn);
        btnSignIn.setOnClickListener(new View.OnClickListener() { // open activity
            @Override
            public void onClick(View view) {
                openActivity();
            }
        });

    }

    private void openActivity() { // open activity
        Intent intent = new Intent(this, SignInPage.class);
        startActivity(intent);
    }

    @Override
    public void onClick(View view) { // is check implemented
        String Email = etEmail.getText().toString();
        String Password = etPassword.getText().toString();

        if (view == btnLogin) {
            IsCheck str = new IsCheck(Email);
            msg = msg + str.checkEmail();

            if (msg.equals("")) {
                Intent intent = new Intent(this, AllUsersActivity.class);
                startActivity(intent);
            }

            else {
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                msg = "";
            }
        }
    }
}
