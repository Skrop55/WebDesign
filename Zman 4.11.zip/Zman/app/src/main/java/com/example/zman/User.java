package com.example.zman;

public class User {
    String Email, Password;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    long id;

    public String getGmail() {
        return Email;
    }

    public void setGmail(String gmail) {
        Email = gmail;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public User(String gmail, String password) {
        Email = gmail;
        Password = password;
    }
}
