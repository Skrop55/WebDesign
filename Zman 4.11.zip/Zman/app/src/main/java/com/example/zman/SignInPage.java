package com.example.zman;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignInPage extends AppCompatActivity implements View.OnClickListener {
    Button btnSignIn2;
    EditText etEmail2, etPassword2;
    String msg = "";
    UserOpenHelper uh1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_page);
        uh1 = new UserOpenHelper(this);

        etEmail2 = findViewById(R.id.etEmail2);
        etPassword2 = findViewById(R.id.etPassword2);
        btnSignIn2 = findViewById(R.id.btnSignIn2);

        btnSignIn2.setOnClickListener(this); // is check implemented
    }

    @Override
    public void onClick(View view) { // is check implemented
        String Email = etEmail2.getText().toString();
        String Password = etPassword2.getText().toString();

        if (view == btnSignIn2) {
            IsCheck str = new IsCheck(Email);
            msg = msg + str.checkEmail();

            if (msg.equals("")) {
                User u1 = new User(Email, Password);
                uh1.open();
                uh1.createUser(u1);
                uh1.close();
                Intent intent = new Intent(this, TaskList.class);
                startActivity(intent);
            }

            else {
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                msg = "";
            }
        }
    }
}
